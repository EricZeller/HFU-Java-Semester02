package Aufgabe3;

public class SFR extends Currency {
    @Override
    public String getName() {
        return "SFR";
    }
}