package Aufgabe3;

public class USD extends Currency {
    @Override
    public String getName() {
        return "USD";
    }
}