package Aufgabe3;
public class Euro extends Currency {
    @Override
    public String getName() {
        return "EUR";
    }
}