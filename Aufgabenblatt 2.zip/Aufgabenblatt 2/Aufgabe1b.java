class Aufgabe1b {
    public static void main(String[] args) {
        System.out.println(Float.parseFloat("15"));
        System.out.println(Float.parseFloat("Hello"));
    }    
}
