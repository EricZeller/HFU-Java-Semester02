public abstract class Sorter<E extends Comparable<E>> {
    public abstract void sort(E[] array);
}