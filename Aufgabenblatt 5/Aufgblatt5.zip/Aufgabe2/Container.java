public interface Container {
    int size();
    boolean add(int number);
    boolean remove(int number);
    boolean contains(int number);
} 
