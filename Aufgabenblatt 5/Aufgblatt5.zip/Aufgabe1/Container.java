public interface Container {
    int size();
    //int getArrayLength();
    boolean add(int number);
    boolean remove(int number);
    boolean contains(int number);
} 
